import { NextRequest, NextResponse } from "next/server";
import { sendContactNotification } from "@/lib/email";
import { rateLimit } from "@/lib/rateLimit";

export async function POST(request: NextRequest) {
  try {
    // Spam protection: max 5 messages / 15 min per IP
    const limited = rateLimit(request, { limit: 5, windowMs: 15 * 60 * 1000 });
    if (limited) return limited;

    const body = await request.json();
    const { name, email, subject, message, topic, orderNumber } = body;

    // Validate required fields
    if (!name || !email || !subject || !message) {
      return NextResponse.json(
        { error: "Pflichtfelder fehlen" },
        { status: 400 }
      );
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: "Ungültige E-Mail-Adresse" },
        { status: 400 }
      );
    }

    // Send notification to the store inbox
    const sent = await sendContactNotification({
      name,
      email,
      subject,
      message,
      topic: typeof topic === "string" ? topic : undefined,
      orderNumber: typeof orderNumber === "string" ? orderNumber.trim() || undefined : undefined,
      locale: request.cookies.get("hausku_locale")?.value,
    });

    if (!sent) {
      return NextResponse.json(
        { error: "E-Mail-Versand fehlgeschlagen" },
        { status: 500 }
      );
    }

    return NextResponse.json({ success: true }, { status: 200 });
  } catch (error) {
    console.error("POST /api/contact error:", error);
    return NextResponse.json(
      { error: "Interner Serverfehler" },
      { status: 500 }
    );
  }
}

// nodemailer requires the Node.js runtime (not Edge)
export const runtime = "nodejs";
